<?php
$con=mysqli_connect("localhost","id18114471_ragnarssons","iM/_>->Dm01e-qf-","id18114471_esp8266");// server, user, password, database
?>